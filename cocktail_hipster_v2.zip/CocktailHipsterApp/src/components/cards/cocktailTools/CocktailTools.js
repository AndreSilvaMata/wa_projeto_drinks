import React from 'react'
import './CocktailTolls.css'
import jigger from '../../../images/jigger.jpg'
import shaker from '../../../images/shaker.jpg'
import strainer from '../../../images/strainer.jpg'
import juicer from '../../../images/juicer.jpg'
import mixing from '../../../images/mixing.jpg'
import spoon from '../../../images/spoon.jpg'
import muddler from '../../../images/muddler.jpg'


export default function CocktailTools() {
  return (
    <section className='card-container tools-background'>
    <h1 style={{fontSize: 50}}>Cocktail Tools</h1>
    <br />
    <hr />
    <h2>Jigger</h2>
    <img src={jigger} alt={'jigger'}/>
    <p>The way I usually find out what the most essential cocktail tools truly are, is when I’m either on vacation or at a friend’s house and trying to make drinks.
    You discover very quickly what the most painful items are to be missing, and for me, a proper jigger is top of the list.
    For the un-initiated a jigger is essentially just a fancy two sided shot glass that allows for precise measurements.
    They come in all different sizes and style, but the most useful for me is the standard 1oz/2oz jigger.
    I particularly like items from A Bar Above, they make fantastic bar tools and they’re jigger in particular is great, as they added in notches by the 1/4 oz inside of it – so you can truly get precise.
    If you’re making any craft cocktail that requires precise measurements, this is a must have. Unless you like making your drinks using a tablespoon….</p>
    <br />
    <hr />
    <h2>Boston Shaker</h2>
    <img src={shaker} alt={'shaker'}/>
    <p>There’s a very good chance you have a shaker. There’s also a very good chance your shaker sucks.
    All too often I see people buy shakers because “it looks cute” or because it has a built in strainer.
    Every single time I’ve used a shaker like that I’m disappointed. Either it leaks horribly, or you have trouble getting the lid off, or it gets too messy – invest in a good shaker!
    The standard Boston Shaker is the style that comes with two stainless steel cups, one smaller than the other that fits inside.
    This is what you want.
    It doesn’t look fancy. The strainer isn’t built in. But it will allow you to easily make fantastic shaken drinks without the headaches those “pretty” ones give you.
    There’s a reason that this is what you see nearly all truly high quality bartenders using.
    It’s worth noting that I also prefer the full stainless steel shaker, as opposed to the ones that have a pint glass on one side. I’m always terrified I’ll break the glass…</p>
    <br />
    <hr />
    <h2>Hawthorne Strainer</h2>
    <img src={strainer} alt={'strainer'}/>
    <p>If you’re using a Boston Shaker, then obviously it’s not going to have a built in strainer. To to fix this, you’ll want what’s called a hawthorne strainer.
    This is a strainer that includes a coil spring to fit around your shaker and to ensure that no ice or pulp gets into the drink.
    I’ve personally rarely had any issues with the ones I’ve used, so any should do, but I’ve had great luck with this one.
    </p>
    <br />
    <hr />
    <h2>Hand juicer</h2>
    <img src={juicer} alt={'juicer'}/>
    <p>The absolute worst is when you show up to a vacation house or a friends 
    and realize there’s no juicer. Daiquiris are my go to drink to make when you’ve got a lot of guests, 
    as they’re super easy to make and you can do a couple at a time.
    Try doing that without a juicer…
    This is something I use all the time, so getting a high quality one is worth the investment. 
    I also like the ones that are slightly larger that can do lemons – 
    they work just as well with limes.</p>
    <br />
    <hr />
    <h2>Mixing glass</h2>
    <img src={mixing} alt={'mixing glass'}/>
    <p>Contrary to what you may have been told, you do not shake every single cocktail.
    In fact, the majority of the cocktails I drink these days are stirred cocktails
    - old fashioned, manhattan, negroni etc...
    On a very broad level, you usually shake things with citrus, and stir things that don’t have citrus. 
    There are plenty of instances where that is broken, but it’s a good starting point.</p>
    <br />
    <hr />
    <h2>Bar spoon</h2>
    <img src={spoon} alt={'bar spoon'}/>
    <p>
    Yes, technically you can use any spoon to stir your cocktails. 
    But again, you’d be amazed how much more effective a long stem proper bar spoon is for mixing.
    If you mix a lot of drinks, a bar spoon will also be much more comfortable for your hand. 
    I can’t tell you how many times I’ve been at one of the aforementioned friends houses 
    trying to mix drinks in a pint glass with a regular spoon that was barely 
    long enough to reach the top of the glass.
    This is a very cheap way to make creating stirred cocktails much more enjoyable.
    </p>
    <br />
    <hr />
    <h2>Muddler</h2>
    <img src={muddler} alt={'muddler'}/>
    <p>
    Finally the last item in our “almost essential” category is a muddler. Now you may be the type of person who hardly ever makes a drink that requires muddling. 
    Great, move this to the bottom of the list.
    But that first time you decide you want to make a mojito - or I suggest the fantastic Smokescreen - 
    you’ll wish you’d picked one up.
    There are all kinds of muddlers out there, but whether you go steel or wood,
    my main criteria is that it’s long enough to allow you to grip it outside of the shaker or glass. 
    Anything less than 10 inches can make this difficult.
    </p>
    <br />
    </section>
    )
  }
  