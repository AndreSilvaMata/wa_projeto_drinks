import React from 'react'
import { useSelector } from 'react-redux'
import { useNavigate, useParams } from 'react-router-dom'
import './SingleCocktailDesc.css'
import {ImCross} from 'react-icons/im'

export default function SingleCocktailDesc() {


    let {id} = useParams()

    let navigate = useNavigate()

    const {drinks} = useSelector(state => state.items.items)

    const drink = drinks?.find((d )=> d.idDrink === id)

    const 
    {
      idDrink, strDrink, strDrinkThumb, strInstructions, strIngredient1, strMeasure1, strIngredient2, strMeasure2, strIngredient3, strMeasure3, strIngredient4, strMeasure4, strIngredient5, strMeasure5, strIngredient6, strMeasure6, strIngredient7, strMeasure7
    } 
    = drink;

  return (
    <section className='single-cocktail-container'>
        <article id={idDrink} className='single-cocktail'>
          <button type='button' onClick={()=> navigate(-1)} className='backX'><ImCross /></button>
            <h1>{strDrink}</h1>
            <img src={strDrinkThumb} className='single-item-img' alt={strDrink}></img>
            <p className='ingredients'>{strIngredient1} <span className='measures'>{strMeasure1}</span></p>
            <p className='ingredients'>{strIngredient2} <span className='measures'>{strMeasure2}</span></p>
            <p className='ingredients'>{strIngredient3} <span className='measures'>{strMeasure3}</span></p>
            <p className='ingredients'>{strIngredient4} <span className='measures'>{strMeasure4}</span></p>
            <p className='ingredients'>{strIngredient5} <span className='measures'>{strMeasure5}</span></p>
            <p className='ingredients'>{strIngredient6} <span className='measures'>{strMeasure6}</span></p>
            <p className='ingredients'>{strIngredient7} <span className='measures'>{strMeasure7}</span></p>
            <p className='instructions'>{strInstructions}</p>
            <button type='button' onClick={()=> navigate(-1)}> Back </button>
            <p>{}</p>
        </article>
    </section>
  )
}