import '../OurCocktails.css'
import './singleCocktail.css'
import { Link } from 'react-router-dom';


export default function SingleCocktail(props) {
    
    // const {drinks} = useSelector(state => state.items.items)
 
    const {idDrink, strDrink, strDrinkThumb, strCategory, strAlcoholic} = props.c;

    return (
            <article className='cocktail-item'>
                <Link to={`/description/${idDrink}`}>
                    <div id={idDrink} className="cocktail-item">
                        <h3>{strDrink}</h3>
                        <img src={strDrinkThumb} alt={strDrink}/>
                        <p>{strCategory} - {strAlcoholic}</p>
                    </div>
                </Link>
            </article>
           )
         }
