import { useSelector } from 'react-redux'
import './OurCocktails.css'
import SingleCocktail from './singleCocktail/SingleCocktail'

function OurCocktails(){

    const {drinks} = useSelector(state => state.items.items)

    console.log('CLG DE OURCOCKTAILS')
    
    return(
        <div className='container'>
            <div className="title">
                <h1>OUR COCKTAILS</h1>
                <hr></hr>
            </div>

            
            <section className='filters-container'>
                <h4>Filters:</h4>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="alcoholic" />
                    <label class="form-check-label" for="alcoholic">
                        Alcoholic
                     </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="nonAlcoholic" />
                    <label class="form-check-label" for="Non-Alcoholic">
                        Non-Alcoholic
                     </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="Shot" />
                    <label class="form-check-label" for="Shot">
                        Shot
                     </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="ordinary" />
                    <label class="form-check-label" for="ordinary">
                        Ordinary Drink
                     </label>
                </div>
            </section>
            <hr/>
            <section className='cocktails'>
            {drinks?.map((cocktail, i) => <SingleCocktail key={cocktail.idDrink} c={cocktail}/>)} 
            </section>
        </div>
    )
}

export default OurCocktails;