import React, {useState, useEffect} from 'react'
import './NonAlcoholicCard.css'


export default function NonAlcoholicCard() {

  const [data, setData] = useState([]);

  // fetch assincrono
  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch(
        "https://thecocktaildb.com/api/json/v1/1/search.php?s=i"
      );
      const newData = await response.json();
      setData(newData.drinks);
    };

    fetchData();
  }, []);

  // console.log(data);

  return (
    <section className='nonAlcohol-container'>
      {
          data.map((item) => {
            if (item.strAlcoholic !== 'Alcoholic') {
              return (
                <article key={item.idDrink}>
                        <h2> {item.strDrink}</h2>
                        <img src={item.strDrinkThumb} />
                        <p><b><i>Category:</i></b> {item.strCategory}</p>
                        <p><b><i>Type:</i></b> {item.strAlcoholic}</p>                                                
                        <p><b><i>Glass type:</i></b> {item.strGlass}</p>                                                
                        <p><b><i>Main ingredient:</i></b> {item.strIngredient1}</p> 
                        <p><b><i>How to mix:</i></b> {item.strInstructions}</p>
                </article>
              )
            }
          })
        }
    </section>
  )
}
