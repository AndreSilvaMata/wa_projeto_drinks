import React from 'react'
import './PortugalSpots.css'
import aguardente from '../../../images/aguardente.jpg'
import medronho from '../../../images/medronho.jpg'
import ginja from '../../../images/ginjinha.jpg'
import beirao from '../../../images/beirao.jpg'
import creme from '../../../images/creme.jpg'
import verde from '../../../images/verde.jpg'
import porto from '../../../images/porto.jpg'
import melosa from '../../../images/melosa.jpg'
import amendoa from '../../../images/amendoa.jpg'
import cachaca from '../../../images/cachaca.jpg'
import gin from '../../../images/gin.jpg'

export default function PortugalSpots() {

  // https://wetravelportugal.com/portuguese-drinks/ - fonte

  return (
    <section className='card-container'>
      <h1>Drinks You Need to Try in Portugal</h1>
      <p>Portugal’s most famous drink might be port, and its wine industry quite well known, but this article isn’t really about those typical drinks Portugal offers. Unknown to a lot of first time visitors, is that Portugal actually has a thriving drinks industry with many many other types available. Lots of them traditional, made with local ingredients, and not actually well known outside of Portugal. The great thing is they’re widely available in Portugal if you know where to look, and they make great gifts for fans of drinks inside and outside of Portugal. For cocktail connoisseurs they make a great addition, or twists to many traditional recipes. Read on to discover 11 Portuguese drinks you need to try!</p>
      <br />
      <hr />
      <h2>Aguardente</h2>
      <img src={aguardente} alt={'aguardente'} />
      <p>Aguardente literally translates as firewater and it has quite the reputation in Portugal. It’s believed that it gets its name for the burning sensation it leaves in your throat! The supermarket variety is usually around 40%, but most locals will tell you it can be found at around 70% if you know who to ask. What is Aguardente? The most common explanation given that it’s a fermented, and distilled alcohol made from a variety of fruits and grains, depending on the locale. In the Algarve, aguardente is typically made from medronho (see below), but also oranges and even figs. In the north and the wine growing regions, often it’s the grape must or the grapes unworthy of wine production. Aguadente Bagaceira being the most famous example. In Madeira, typically sugarcane is used, leading to Aguardente de Cana Madeirense.</p>
      <br />
      {/* </div>
      </div> */}
      <hr />
      <h2>Aguardente de medronhos</h2>
      <img src={medronho} alt={'medronho'} />
      <p>In the Algarve, aguardente de medronho is perhaps the most popular. The medronho is a small spikey fruit found across southern Portugal, it’s also called a strawberry tree fruit. It has nothing to do with strawberries though and tastes nothing like them. The result is a clear alcohol that is usually drank neat as a digestif. It’s both very traditional and a typical drink in the south of Portugal. Similarly to aguardente, you’ll find the supermarket variety hovers around 40%, but the local and homemade stuff can get much much stronger. If you listen to the locals, they’ll tell you it can heal everything from sore throats to stomach conditions. If you don’t fancy purchasing a whole bottle of the stuff, many bars and cafés will sell shots for less than €1.</p>
      <br />
      <hr />
      <h2>Melosa</h2>
      <img src={melosa} alt={'melosa'} />
      <p>If aguardente de medronho sounds a bit fearsome to you then you may want to try melosa. Melosa is a liqueur that is much more friendly than straight aguardente de medronho. It’s a liqueur made of medronho blended with honey and sometimes spices like cinnamon or vanilla. It results in a pleasant experience and a sweet liqueur that is again served as a digestif. It’s actually where we recommend you start if you’re tipping your toes into the medronho world. You’ll find it mostly in the places that have both considerable honey and aguardente production like Monchique.</p>
      <br />
      <hr />
      <h2>Ginja or Ginjinha</h2>
      <img src={ginja} alt={'ginja'} />
      <p>Ginjinha or just Ginja is a liqueur made from sour cherries that is linked to the towns of Óbidos, Alcobaça and Lisbon. It’s an infusion of aguardente locally grown produce, this time the sour cherry (Ginja), and sugar. The drink is enjoyed throughout the country, and is popular across the Algarve and in bigger cities. If you’ve been to any of the local food or chocolate festivals, you’ll often see it poured into edible chocolate shot cups. The liqueur is typically ruby red, sweet and with a strong cherry aroma. It is best served as an aperitif or a digestif, preferably neat. Some of the more artisanal brands will leave a few of the cherries in the bottle, and sometimes a couple will be included in the cup your served.  </p>
      <br />
      <hr />
      <h2>Licor Beirão</h2>
      <img src={beirao} alt={'beirao'} />
      <p>For the Brits, think Pimms, for the Germans maybe Jägermeister, it’s a similar concoction with a similar history. An alcohol blended with a secret selection of herbs and spices that was originally medicinal. That’s before the locals got a taste, and the practice of using alcohol as medicine was outlawed. It’s less well known outside of Portugal, but you’ll find it everywhere in Portugal. It’s been marketed as the national drink of Portugal for several decades. Licor Beirão is an aromatic and fairly sweet liqueur with subtle flavours of aniseed, cinnamon and even notes of orange. It’s drank neat over ice, added to coffee, and even ice cream has been flavoured with it. It’s deliciously and uniquely Portuguese.</p>
      <br />
      <hr />
      <h2>Licor de Amêndoa Amarga</h2>
      <img src={amendoa} alt={'amendoa amarga'} />
      <p>Commonly known as amêndoa amarga or by the name of its most famous producer Amarguinha. It is a liqueur made from the bitter almond. The bitter almond tree grows plentifully around the Algarve, but was largely considered inedible due to the bitter taste and rather poisonous almonds. However, when macerated and distilled, the bitter flavour and cyanide of the almond is eliminated resulting in a sweet liqueur not too dissimilar to the much more widely known Italian Amaretto. The most popular brand comes from the Algarve, Amarguinha, but the name is sometimes used to describe all Licor de Amêndoa Amarga. It is often served as an aperitif, as a digestif at the end of a meal, or used in cocktails. During the summer you’ll also see it served on ice, with a slice and squeeze of lemon.</p>
      <br />
      <hr />
      <h2>Creme de Pastel de Nata</h2>
      <img src={creme} alt={'creme'} />
      <p>In a similar vein to Bailey’s or Sangster’s rum cream, Creme de Pastel de Nata is Portugal’s very own version. The most popular and pioneer of the idea is Licor 35. Who state after 21 attempts to get it right, they settled on a blend of sample 3 and 5. Several other brands, both artisanal and discount, have come up with their own versions often simply called licor natas. It’s supposedly based on the flavours of a pastel de nata but in practice, it’s less custard and much more simply vanilla and cream. Served over ice it’s a delicious but a very sweet digestif, but is also added to coffee to create a Portuguese inspired Irish coffee. You’ll also find ice cream and other desserts flavoured with it!</p>
      <br />
      <hr />
      <h2>Cachaça</h2>
      <img src={cachaca} alt={'cachaca'} />
      <p>Several of the Portuguese islands have a rich history in sugar production. What followed historic sugarcane production? Rum! Madeira is considered the heart of Portuguese rum production and you’ll find several brands like William Hinton have been operating on the island since the early 19th century. Cachaça also gets a worthy mention here. Reportedly in the 16th century the Portuguese took their stills from Madeira to Brazil to follow the much larger scale sugar cane production. They began to produce Cachaça, which is now much more widely known and protected as a Brazilian export. The difference between Cachaça and rum? Well Cachaça is made from fermented sugar cane juice, whereas rum is made from molasses. Molasses being a byproduct of boiling the sugar cane and juice to extract as much sugar as possible. You’ll be able to find both Portuguese rum and Brazilian Cachaça across Portugal. If you’re in Madeira, you’ll also find Aguardente de Cana, the original sugar cane spirit before it became Cachaça in Brazil. For those looking on mainland Portugal. Alentejo based distillery Black Pig have started producing their own rum alongside their award winning gin.</p>
      <br />
      <hr />
      <h2>Portuguese Gin</h2>
      <img src={gin} alt={'gin'} />
      <p>Speaking of gin, Portugal might not be the first country to come to mind when you think of it, but that hasn’t stopped the Portuguese getting involved recently. Many of the local producers have created their own gins, with their own mixes of locally grown botanicals. You’ll find a few brands have stuck to the more traditional flavors of juniper and produce high quality London dry gin. However, you’ll also discover a few local distilleries have experimented with more Mediterranean botanicals like oranges, lemons and almond. On the truly Portuguese side, Gin Edmundo infuse theirs with Alvarinho grapes used traditionally in Vinho Verde. For a more tropical variety, Azores based distillery Goshawk flavour their’s with locally grown passion fruit. With over 20 Portuguese brands of Gin across the mainland, and islands, you’re usually not too far from a local distillery.</p>
      <br />
      <hr />
      <h2>Vinho Verde</h2>
      <img src={verde} alt={''} />
      <p>Although wine is skipped off this list because it’s one of the most famous drinks Portugal offers. There is a particular type of wine that is less widely known and equally delicious. Vinho Verde! Vinho Verdes are light, fresh, and slightly sparkling, and commonly served chilled in the summer. Officially, they’re not recognised as sparkling, but they do offer a slight and refreshing fizz at the tip of your tongue. The verde in its name has two conflicting origin stories, neither to do with the colour of the wine itself. One being that its from the Minho region, a region that is lush, green and gets lots of rain. The other refers to its age, and suggests the green means young, and that it is traditionally drank much younger than normal wines from Portugal. Despite the green name, Vinho Verde wine is also available in red - tinto - and rosé varieties.</p>
      <br />
      <hr />
      <h2>Vinho do Porto</h2>
      <img src={porto} alt={'porto'}/>
      <p>Last and most definitely not least is Port or Vinho do Porto to give its full name. Does Port need an introduction? It is perhaps Portugal’s most famous drink, but we think it might still need one. In my experience, an old bottle of Ruby port was dragged out by my grandparents each Christmas. It was only when I arrived in Portugal that I was introduced to quite literally a world of ports, that went much further than a simple ruby port. There are multiple varieties and quite literally a port for everyone and every occasion. A sweet port might be served as a dessert wine, or simply at the end of a meal. Served with a cheeseboard you might find a vintage ruby, or an aged tawny. You’ll also find rubies used in a variety of Portuguese cuisine, especially in reductions or sauces. The newer rosé port is finding its feet as a chilled aperitif. Port is even being used as a replacement in the classic gin and tonic to create a Portonic, that’s growing in popularity across Portugal.</p>
    </section>
  )
}
