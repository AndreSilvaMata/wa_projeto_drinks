import React from 'react'
import './DayCocktail.css'


export default function DayCocktail() {

  return (
    <section className='card-container'>
      cocktail of the day
    </section>
  )
}
