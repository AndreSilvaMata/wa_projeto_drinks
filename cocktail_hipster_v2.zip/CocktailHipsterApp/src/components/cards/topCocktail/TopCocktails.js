import React from 'react'
import './TopCocktails.css'
import bourbon from '../../../images/bourbon.jpg'
import man from '../../../images/man.jpg'
import psm from '../../../images/psm.jpg'
import expmartini from '../../../images/expmartini.jpg'
import lii from '../../../images/lii.jpg'
import margarita from '../../../images/margarita.jpg'
import dm from '../../../images/dm.jpg'
import russian from '../../../images/russian.jpg'
import negroni from '../../../images/negroni.jpg'
import adiosmotherfucker from '../../../images/adiosmotherfucker.jpg'

export default function TopCocktails() {

  // https://www.liquor.com/popular-cocktails-4845950 - fonte

  return (
    <section className='card-container top-cocktails'>
      <section>
        <h1><strong>The 10 Most Popular Cocktails Right Now</strong></h1>
        <hr />
        <h2>01 Bourbon Old Fashioned</h2>
        <img src={bourbon} />
        <p>Little more than a slug of whiskey seasoned and sweetened, and yet the embodiment of a cocktail as originally defined, which is to say, a combination of spirit, sugar, water and bitters, this classic remains as popular today as it was 200 years ago.</p>
        <br />
        <hr />
        <h2>02 Manhattan</h2>
        <img src={man} />
        <p>Cocktails don't get any more classic than this elegant mix of rye or bourbon, sweet vermouth and bitters that drinkers have been sipping for close to a century and a half. Garnish with a brandied cherry if you're a traditionalist, or a lemon twist for a more modern touch.</p>
        <br />
        <hr />
        <h2>03 Porn Star Martini</h2>
        <img src={psm} />
        <p>This cocktail recipe was a new addition to Liquor.com just last year, and it immediately became one of our most popular recipes. It's a crowd-pleasing mix of vanilla and passionfruit flavors, and what’s not to love about a drink that was designed to come with a Champagne chaser?</p>
        <br />
        <hr />
        <h2>04 Expresso Martini</h2>
        <img src={expmartini} />
        <p>Reports of the recent resurgence of this caffeinated ’80s favorite aren’t exaggerated. There are plenty of riffs out there, but it’s worth memorizing the original recipe, a mix of vodka, coffee liqueur, espresso, and simple syrup.</p>
        <br />
        <hr />
        <h2>05 Bourbon Old Fashioned</h2>
        <img src={lii} />
        <p>It’s been a long couple of years, and apparently plenty of us are still Going Through It. This drink is here to help. It’s not that it contains so much more alcohol than many other drinks, but something about this combination of four different spirits and a liqueur (plus lemon juice and cola) makes this concoction seem like it’ll get the job done more efficiently than any other mixed drink.</p>
        <br />
        <hr />
        <h2>06 Margarita</h2>
        <img src={margarita} />
        <p>Combining tangy lime juice with sweet, orangey triple sec and, of course, the most popular of agave spirits, this drink has become one of the most beloved in the cocktail canon. There are endless riffs, but we think this version, splitting the difference between a Tommy's Margarita and the classic triple sec-heavy version, is the best.</p>
        <br />
        <hr />
        <h2>07 Dirty Martini</h2>
        <img src={dm} />
        <p>Briny yet elegant, saline yet simple, the Dirty Martini, which adds a splash of olive brine to the classic Martini format of gin or vodka and dry vermouth, is an eternal go-to for sippers looking for a bit of sophistication.</p>
        <br />
        <hr />
        <h2>08 White Russian</h2>
        <img src={russian} />
        <p>Let’s face it, The Dude was on to something with his go-to drink. The now-classic combination of vodka, Kahlúa, and heavy cream is as comforting as a cozy winter blanket and couldn't be simpler to make.</p>
        <br />
        <hr />
        <h2>09 Negroni</h2>
        <img src={negroni} />
        <p>This classic cocktail dropped from the number-two spot last year. We can only assume it’s because everyone has already memorized the equal-parts mix of gin, Campari, and sweet vermouth. With apologies to Stanley Tucci, this drink (as with a Martini; sorry, Bond) should never ever ever be shaken, only stirred. </p>
        <br />
        <hr />
        <h2>10 Adios Mother Fucker</h2>
        <img src={adiosmotherfucker} />
        <p>This mix, essentially a blue Long Island Iced Tea, peaked in popularity in late January 2021. We’re pretty sure we can guess the reason. It’s always delightful when the world has not only a reason to raise a glass in celebration but also the perfect drink with which to celebrate.</p>
        <br />
      </section>
    </section>
  )
}
