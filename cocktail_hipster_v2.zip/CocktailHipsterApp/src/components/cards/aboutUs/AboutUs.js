import React from 'react'
import './AboutUs.css'

export default function AboutUs() {
  return (
    <section className='about-card'>
      <h2>So you're at home alone and you feel like having a cocktail 
but you're not quite sure which one and how to make it? <br />
<br />
Or you are having some friends come over that you want to impress? <br />
<br />
We've got you covered! <br /> <br /> 
The Cocktail Hipster will help you find the right cocktail, for the right moment.
We'll provide you with ideas for different cocktails - with or without alcohol - 
including a list of the top 25 cocktails right now, with
our own list of suggestions, tips on drinks you need to try in Portugal as well as
the most important tools you'll need to make your cocktails.</h2>
    </section>
  )
}
