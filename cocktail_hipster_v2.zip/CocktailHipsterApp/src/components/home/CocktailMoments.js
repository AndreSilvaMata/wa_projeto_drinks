import React from 'react';
import { Link } from 'react-router-dom';
import margarita from "../../images/margarita.jpg";
import shot from "../../images/shot.jpg";
import nonAlcoholic from "../../images/nonAlcoholic.jpg";
import alcoholic from "../../images/alcoholic.jpg";
import "./CocktailMoments.css";

export default function CocktailMoments() {
    return (
        <section className="home-moments">

        <div className="moments-btn">
            <Link to="cocktails">
            <h3>Cocktail </h3>
            <img className="momentsCard" src={margarita} />
            </Link>
        </div>
        
        <div className="moments-btn">
            <Link to="shots">
                <h3>Shot</h3>
                <img className="momentsCard" src={shot} />
            </Link>
        </div>

        <div className="moments-btn">
            <Link to="alcoholic">
                <h3>Alcoholic</h3>
                <img className="momentsCard" src={alcoholic} />
            </Link>
        </div>

        <div className="moments-btn">
            <Link to="non-alcoholic">
                <h3>Non Alcoholic</h3>
                <img className="momentsCard" src={nonAlcoholic} />
            </Link>
        </div>
        </section>
        )
    }
    