import React, { useState } from 'react';
import { useSelector } from "react-redux";
import { useEffect } from "react";
import "./CocktailDay.css";

export default function CocktailDay() {
    
  const {drinks} = useSelector(state => state.items.items)
   
  const [drinkSeleted, setDrinkSeleted] = useState()

  useEffect(() => {
    if (!drinks?.length){
      return 
    }
     handleDrinkSelected()
  }, [drinks])
  
    
  const handleDay = () => {
    const min = Math.ceil(0);
    const max = Math.floor(drinks.length);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  const handleDrinkSelected = () => {
    const drinkSelected = drinks.filter((item, index) => {
      return index === handleDay()
     });
    //  console.log(drinkSelected[0])
     setDrinkSeleted(drinkSelected[0])
  }


  return (
    <section className="home-day">
        {
          <article>
            <h2>Cocktail of the day</h2>
            <img src={drinkSeleted?.strDrinkThumb} />
            <h3> {drinkSeleted?.strDrink} </h3>
            <p> <b><i>Category:</i></b> {drinkSeleted?.strAlcoholic}</p>
            <p> <b><i>Type:</i></b> {drinkSeleted?.strCategory} </p>
            <p> <b><i>Glass type:</i></b> {drinkSeleted?.strGlass}</p>
            <p> <b><i>Main ingredient:</i></b> {drinkSeleted?.strIngredient1},   {drinkSeleted?.strIngredient2}, {drinkSeleted?.strIngredient3},   {drinkSeleted?.strIngredient4} {drinkSeleted?.strIngredient5} </p>
            <p> <b><i>How to mix:</i></b> {drinkSeleted?.strInstructions}</p>
          </article>
        }
    </section>
  )
}
