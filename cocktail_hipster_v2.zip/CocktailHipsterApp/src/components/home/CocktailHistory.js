import React from 'react';
import "./cocktailHistory.css"

export default function CocktailHistory() {
  return (
    <section className="home-history">
    {/* ALTERAR A MANEIRA COMO SE CHAMA A CITAÇÃO */}
    <div class="history">
        <h2>The History of Cocktails <span> <a href="https://thecocktailsociety.uk/the-history-of-cocktails/"> </a>1</span> </h2>
        
        <h3>Advanced mixology guide us through the history of the cocktail</h3>
        <p>For those who love cocktails, it’s time to take a trip down memory lane.</p>
        <p>These alcoholic beverages made using spirits blended with other ingredients have been around since the 1800s, and there have been many changes to them since then.</p>
        <p>Let’s explore the transitions that occur throughout the history of cocktails, along with other historical facts you need to know about these beloved mixed drinks.</p>
        <h3>Origin Story</h3>
        <p>Cocktails were initially inspired by British punches, which contained spirits, fruit juices, and spices in big bowls. The term “cocktail” was first seen on March 17, 1798, as referenced from a newspaper.</p>
        <p>Though the origin of mixed drinks can be traced back to the 17th century, it wasn’t clear where, who, and how the “original” cocktail was created.</p>
        <p>The first-ever reference to cocktails appeared in a spoof editorial in the Farmer’s Cabinet (Amherst, New Hampshire, April 28, 1803).</p>
        <p>It talked of a “lounger” who, while nursing an 11 a.m. hangover, “Drank a glass of cocktail – excellent for the head…”</p>
        <p>But it wasn’t until 1806 when The Balance and Columbian Repository of Hudson, New York pinned the definition down to what we know of cocktails today: “A stimulating liquor composed of any kind of sugar, water, and bitters.”</p>
        <h3>Revival of the Classic Cocktails</h3>
        <p>In the mid-20th century, cocktail drinks took a step back as drug cultures overtook them.</p>
        <p>However, around the 90s, people like Dale Degroff of New York’s famous Rainbow Room revived the classic cocktail culture from Professor Thomas’ time.</p>
        <p>Degroff’s craft cocktail movement brought historical values and strict quality standards back to a formerly devolved industry. This new era saw drinks like The Pink Squirrel and shooters such as Training Bra cocktails.</p>
        <p>Mixology also became popular throughout this period. To this day, bartenders have been flourishing.</p>
        <p>As some of Thomas’ original cocktail recipes disappear, new ones such as the Gin Basil Smash emerge daily, keeping the cocktail culture alive.</p>
    </div>
    </section>
  )
}
