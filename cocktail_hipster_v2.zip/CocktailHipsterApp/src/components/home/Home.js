// imports
import "./Home.css";
import CocktailDay from "./CocktailDay";
import CocktailHistory from "./CocktailHistory";
import CocktailMoments from "./CocktailMoments";


export default function Home() {

  return (
    <section className="home-container">
      <CocktailDay />
      <CocktailMoments />
      <CocktailHistory />
    </section>
    );
  }
  