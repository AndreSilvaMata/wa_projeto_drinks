import React from 'react'
import "./footer.css"
import { FaTwitter } from 'react-icons/fa'
import { FaFacebook } from 'react-icons/fa'
import { FaInstagram } from 'react-icons/fa'
import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer>
    <ul className='social-icons'>
    <li><FaTwitter size={30} url={'#'}/></li>
    <li><FaFacebook size={30}/></li>
    <li><FaInstagram size={30}/></li>
    <li>
    <Link className='about-us' to='/about-us'>About Us</Link>
    </li>
    </ul>
    </footer>
    )
  }
  