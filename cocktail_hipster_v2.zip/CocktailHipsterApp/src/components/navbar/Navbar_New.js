// imports
import './Navbar_New.css'
import {FaBars, FaTimes} from 'react-icons/fa'
import { useState } from 'react'
import { Link } from 'react-router-dom';
import Logo from '../../images/Logo.png'
import search from '../../images/search.png'


export default function Navbar() {

    // state boleano para estilizar o handler hamburger e fechar o menu
    const [click, setClick] = useState(false);

    const [term, setTerm] = useState("");

    const submitHandler = (e) => {
        e.preventDefault()
    }

    const handleClick = () => setClick(!click)
    const closeMenu = () => setClick(false)

  return (
    <section className='header'>

        {/* <Link className='logo' to='/'> <img src={Logo}  /> </Link> */}

    <nav className='navbar'>
        <div className='hamburger' onClick={handleClick}>
            {click ? (<FaTimes size={30} style={{color: '#fff'}} />) : (<FaBars size={30} style={{color: '#fff'}}/>)}
        </div>

        <Link className='logo' to='/'> <img src={Logo}  /> </Link>

        <ul className={click ? 'nav-menu active' : 'nav-menu'}>
            <li className='nav-item'>
                <Link className='nav-menu-link' to='/world-top-cocktails' onClick={closeMenu}>Top 10 Cocktails</Link>
            </li>
            <li className='nav-item'>
                <Link className='nav-menu-link' to='/our-cocktails' onClick={closeMenu}>Our Cocktails</Link>
            </li>
            <li className='nav-item'>
                <Link className='nav-menu-link' to='/portugal-drinks' onClick={closeMenu}>Portuguese Drinks</Link>
            </li>
            <li className='nav-item'>
                <Link className='nav-menu-link' to='/cocktail-tools' onClick={closeMenu}>Cocktail Tools</Link>
                {/* <a href='#about' onClick={closeMenu}>Search</a> */}
            </li>
            <li className='nav-search'>
                <form onSubmit={submitHandler}>
                    <input type='text' value={term}
                    placeholder={'search our cocktails'}
                    onChange={(e) => setTerm(e.target.value)}
                    />
                </form>
                <button className='search-btn' onClick={submitHandler}> 
                    <img src={search} style={{width:25, height:25, padding:0}} /> 
                </button>
            </li>
        </ul>


    </nav>
</section>
  )
}
