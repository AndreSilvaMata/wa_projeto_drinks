// imports
import './Navbar.css'
import {FaBars, FaTimes} from 'react-icons/fa'
import { useState } from 'react'
import { Link } from 'react-router-dom';
import Logo from '../../images/Logo.png';
import search from '../../images/search.png';
import top from '../../images/top-10.png';
import portugal from '../../images/cocktailPortugal.png';
import tools from '../../images/cocktailShaker.png';
import ourCocktail from '../../images/ourCocktail.png';




export default function Navbar() {

    // state boleano para estilizar o handler hamburger e fechar o menu
    const [click, setClick] = useState(false);

    const handleClick = () => setClick(!click)
    const closeMenu = () => setClick(false)

  return (
    <section className='header'>

        <nav className='navbar'>
        
        <ul className='principal'>
            <li>
                <div className='hamburger' onClick={handleClick}>
                {click ? (<FaTimes size={30} style={{color: '#727272'}} />) : (<FaBars size={30} style={{color: '#727272'}}/>)}
                </div>

                <ul className={click ? 'nav-menu active' : 'nav-menu'}>
                    <li className='nav-item'>
                        <Link className='nav-menu-link' to='/world-top-cocktails' onClick={closeMenu}> <img src={top} />
                        <br />Top 10 Cocktails</Link>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-menu-link' to='/our-cocktails' onClick={closeMenu}> <img src={ourCocktail} /> <br />Our Cocktails</Link>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-menu-link' to='/portugal-drinks' onClick={closeMenu}> <img src={portugal} /> <br /> Portuguese Drinks</Link>
                    </li>
            
                    <li className='nav-item'>
                        <Link className='nav-menu-link' to='/cocktail-tools' onClick={closeMenu}> <img src={tools} /> <br /> Cocktail Tools</Link>
                    
                    </li>
                </ul>

            </li>

            <li>
                <Link className='logo' to='/'> <img src={Logo} /> </Link>
            </li>

            <li>
                <img src={search} style={{width:25}} />
            </li>
        </ul>

        </nav>
    </section>
  )
}
