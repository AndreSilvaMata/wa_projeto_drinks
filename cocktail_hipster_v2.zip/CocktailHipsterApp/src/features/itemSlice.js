import { createSlice } from "@reduxjs/toolkit";

export const initialState = {
    items: [],
    loading: false,
    hasErrors: false,

}

const itemsSlice = createSlice({
    name: "item",
    initialState,
    reducers: {
        getItems: state => {
            state.loading = true;
        },
        getItemsSuccess: (state, {payload}) => {
            state.items = payload;
            state.loading =false;
            state.hasErrors = false;
        },
        getItemsFail: state => {
            state.loading = false;
            state.hasErrors = true;
        },
    },
})

export const { getItems, getItemsSuccess, getItemsFail, hasErrors} = itemsSlice.actions;

// export const itemsSelector = state => state.items.items;
export const itemsSelector = state => state.items;

export default itemsSlice.reducer;


export function fetchItems() {
    return async dispatch => {
        dispatch(getItems())
        try{
            const response = await fetch('https://thecocktaildb.com/api/json/v1/1/search.php?s=i')

            const data = await response.json()

            dispatch(getItemsSuccess(data))

        } catch (error){
            dispatch(getItemsFail())
        }


    }
}

