// import { createSlice } from '@reduxjs/toolkit'

// // const initialState = {
// //     cocktails: [],
// // }

// export const drinksSlice = createSlice({
//     name: 'cocktail',
//     initialState: {cocktails:[]},
//     reducers: {
//         getCocktails: (state, action) => {
//             state.cocktails = action.payload
//         }
//     }
// })

// export const {getCocktails} = drinksSlice.actions;
// export default drinksSlice.reducer;

import { createSlice } from "@reduxjs/toolkit";

export const initialState = {
    items: [],
    loading: false,
    hasErrors: false,

}

const itemsSlice = createSlice({
    name: "item",
    initialState,
    reducers: {
        getItems: state => {
            state.loading = true;
        },
        getItemsSuccess: (state, {payload}) => {
            state.items = payload;
            state.loading =false;
            state.hasErrors = false;
        },
        getItemsFail: state => {
            state.loading = false;
            state.hasErrors = true;
        },
    },
})

export const { getItems, getItemsSuccess, getItemsFail, hasErrors} = itemsSlice.actions;

// export const itemsSelector = state => state.items.items;
export const itemsSelector = state => state.items;

export default itemsSlice.reducer;


export function fetchItems() {
    return async dispatch => {
        dispatch(getItems())
        try{
            const response = await fetch('https://thecocktaildb.com/api/json/v1/1/search.php?s=i')

            // exemplo com uma api diferente
            // const response = await fetch('https://dog.ceo/api/breeds/image/random')
            const data = await response.json()

            dispatch(getItemsSuccess(data))

        } catch (error){
            dispatch(getItemsFail())
        }


    }
}