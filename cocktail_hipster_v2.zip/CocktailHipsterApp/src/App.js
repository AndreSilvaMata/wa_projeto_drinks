//react
import { Routes, Route } from 'react-router-dom';
// componentes
import Navbar from './components/navbar/Navbar_New'
// import Navbar from './components/navbar/Navbar'
import Home from './components/home/Home'
import DayCocktail from './components/cards/dayCocktail/DayCocktail';
import CocktailCard from './components/cards/cocktail/CocktailCard';
import ShotsCard from './components/cards/shots/ShotsCard';
import AlcoholicCard from './components/cards/alcoholic/AlcoholicCard';
import NonAlcoholicCard from './components/cards/nonAlcoholic/NonAlcoholicCard';
import CocktailTools from './components/cards/cocktailTools/CocktailTools';
import TopCocktails from './components/cards/topCocktail/TopCocktails';
import PortugalSpots from './components/cards/portugalSpots/PortugalSpots';
import { useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchItems } from './features/itemSlice';
import OurCocktails from './components/cards/ourCocktails/OurCocktails';
import SingleCocktailDesc from './components/cards/ourCocktails/singleCocktail/singleDescription/SingleCocktailDesc';
import Footer from './components/footer/Footer'
import AboutUs from './components/cards/aboutUs/AboutUs';

function App() {

  const dispatch = useDispatch()
  
  const {drinks} = useSelector(state => state.items.items)
  
  console.log(drinks)
  const cocktailRef = useRef(true)

  useEffect(() => {
    if(cocktailRef.current){
      cocktailRef.current = false;
      return;
  }
    dispatch(fetchItems())
  }, [dispatch])
  



  // julgava ser possivel passar props nas routes mas não :(
  return (
    <div className="App">
      <Navbar />

      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/cocktail-of-the-day' element={<DayCocktail />} />
        <Route path='/cocktails' element={<CocktailCard />} />
        <Route path='/our-cocktails' element={<OurCocktails />} />
        <Route path='description/:id' element={<SingleCocktailDesc />} />
        <Route path='/shots' element={<ShotsCard />} />
        <Route path='/alcoholic' element={<AlcoholicCard />} />
        <Route path='/non-alcoholic' element={<NonAlcoholicCard />} />
        <Route path='/cocktail-tools' element={<CocktailTools />} />
        <Route path='/world-top-cocktails' element={<TopCocktails/>} />
        <Route path='/portugal-drinks' element={<PortugalSpots />} />
        <Route path='/about-us' element={<AboutUs />} />
      </Routes>

      <Footer />
      
    </div>
  );
}


export default App;
